'use strict';
module.exports = class reportValidator {
    constructor() { }

    get_commission_list_data() {
        return {
            owner_id: 'required'
        };
    }
}