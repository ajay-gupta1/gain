module.exports = class Oam_dashboard_Validator {


    dashboard() {
        return {
           owner_id: 'required'
        }
    }
  

}