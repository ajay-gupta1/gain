'use strict';
module.exports = class unitValidator {
    constructor() { }

    get_all_unit_master() {
        return {};
    }

    get_rent_unit_list() {
        return {};
    }

}