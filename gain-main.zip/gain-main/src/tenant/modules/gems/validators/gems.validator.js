'use strict';
module.exports = class gemsValidator { 
    constructor() { }

    syncCustomers() {
        return {};
    }

    processStatus() {
        return {
            process_id: 'required'
        };
    }
}