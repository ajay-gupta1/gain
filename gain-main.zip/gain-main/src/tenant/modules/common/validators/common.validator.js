'use strict';
module.exports = class commonValidator { 
    constructor() { }

    getCommonList() {
        return {};
    }
}