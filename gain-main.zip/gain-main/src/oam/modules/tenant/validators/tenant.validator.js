'use strict';
module.exports = class tenantValidator {
    constructor() { }

   
    list_tenant() {
        return {};
    }
}