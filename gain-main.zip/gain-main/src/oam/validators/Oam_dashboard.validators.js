module.exports = class Oam_dashboard_Validator {


    dashboard() {
        return {
           oam_id: 'required'
        }
    }
  

}