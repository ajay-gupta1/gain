let constants = {
    DEFAULT_DATE_FORMAT:'dd-mm-yyyy',
    true_status:['1','true','active','enabled','enable'],
    false_status:['0','false','inactive','disabled','disable'],
};
module.exports = constants;