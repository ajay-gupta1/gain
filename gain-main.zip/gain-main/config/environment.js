module.exports = {

	development: [
		"Admin-PC",
		'Brijesh-PC.local',
		"localhost:4000",
		"brijesh:4000",
		"Credosyss-Mac-mini.local",
		"Brijeshs-MacBook-Air.local",
		'Macs-MacBook-Pro.local',
		"milan",
		"Admins-iMac.local",
		"Macs-MBP",
		"Brijeshs-Air",
		"sgss5.a2hosting.com",
		"Rakesh-PC",
		"credosys-HP-Laptop-15-bs1xx",
		"fahad",
		"jamshed-HP-Laptop-15-bs0xx",
		"credosys",
		"kool",
		"linux",
		"DESKTOP-DLP924T",
		"DESKTOP-M4OOFPE",
		"credosys-Lenovo-G50-70",
		"DESKTOP-TV8HO4A",
		"dell-credosys",
		"007",
		"credosys-GA-78LMT-USB3-6-0",
		"DESKTOP-BVPFDM8",
		"kripesh",
		"hadrian-aspire-e5-575",
		"Praveens-Mac-mini-2.local",
		"deepak-latitude-3480",
		"mayur-Latitude-3400",
		"ashraf-Latitude-3400",
		"nikhil-Latitude-3400",
		"dipesh",
		"siddhant",
		"rohit-Latitude-3400",
		"guestuser15",
		"sonukumar-Latitude-3490",
		"sid-PC",
		"gaurav-Latitude-3400",
		"nikhil-Latitude-3400",
		"DESKTOP-G91EV05",
		"Dipesh-007",
		"vernost2-Latitude-3400",
		"arati",
		"LAPTOP-9SRR2G0H",
		"DESKTOP-H22DQHO",
		"vernost2-Latitude-3400"
	],
	sit: [
		// "ip-10-11-1-10.ec2.internal"
		// "ip-10-11-0-40"
	],
	uat: [
		"ip-10-11-1-10.ec2.internal", // clubclass
		// "mayur-Latitude-3400",
		// "ip-172-31-26-107", // leela uat
	],
	production: [
		// "ip-172-31-30-116", // leela production
	],

};

